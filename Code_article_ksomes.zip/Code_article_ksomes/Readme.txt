To make a homogeneous fit of the data us data_analysis.py



To test the fitting method on the ballistic model:
	
	1. Generate ballistic profiles with ballistic_model.py for chosen interval of R_1(0) and kinetics parameters
	2. Fit the data with fit_RSdata_BFGS.py
	3. plot the score function with score_fct.py
